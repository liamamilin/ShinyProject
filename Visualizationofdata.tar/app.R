#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

require(semantic.dashboard)
require(shinycssloaders)
require(plotly)
library(gapminder)
require(tidyverse)
library(plyr)

# Data <- read.csv('/Users/milin/Work/data.csv')

# Define UI for application that draws a histogram
ui <-     dashboardPage(
  dashboardHeader( title = "Statistical graphics"),
  dashboardSidebar(
    sidebarMenu(
      menuItem(tabName = "animation",text = "Animation"),
      menuItem(tabName = "ThreeDPlot", text = "ThreeDPlot"),
      menuItem(tabName = "HeatMap", text = "Heat map"),
      menuItem(tabName = "RadarMap", text = "Radar Map"),
      menuItem(tabName = "Distribution", text = "Distribution"),
      menuItem(tabName = "Bar", text = "Bar"),
      menuItem(tabName = "sankey", text = "sankey")
    )
  ),
  dashboardBody(
    tabItems(
      tabItem(
        tabName = "animation",
        h3("Excerpt of the Gapminder data on life expectancy, GDP per capita, and population by country."),
        box(plotlyOutput("animation1") %>% withSpinner(),width = 16),
        br(),
        h3("Random walk"),
        box(plotlyOutput("animation2")%>% withSpinner(),width = 16)
      ),
      tabItem(
        tabName = "ThreeDPlot",
        h3("Random walk"),
        box(plotlyOutput("ThreeDplot1") %>% withSpinner(),width = 16)
      ),
      tabItem(tabName = "HeatMap",
              box(plotlyOutput(outputId = "HeatMap1") %>% withSpinner(),width = 16)
      ),
      tabItem(tabName = "RadarMap",
              box(plotlyOutput(outputId = "RadarMap1" )%>% withSpinner(),width = 16)
      ),
      tabItem(tabName = "Distribution",
              h3("violin"),
              box(plotlyOutput(outputId = "Distribution1")%>% withSpinner(),width = 16),
              br(),
              h3("2D contour histogram"),
              box(plotlyOutput(outputId = "Distribution2")%>% withSpinner(),width = 16),
              br(),
              h3(" histogram"),
              box(plotlyOutput(outputId = "Distribution3")%>% withSpinner(),width = 16),
              br(),
              h3(" box"),
              box(plotlyOutput(outputId = "Distribution4")%>% withSpinner(),width = 16)
              
      ),
      tabItem(tabName = "Bar",
              box(plotlyOutput(outputId = "Bar1")%>% withSpinner(),width = 16)
      ),
      tabItem(tabName = "sankey",
              box(plotlyOutput(outputId = "sankey1")%>% withSpinner(),width = 16)
      )
    )
  )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
  
  data <- reactive({
    
    data <- read.csv('https://raw.githubusercontent.com/plotly/datasets/master/_3d-line-plot.csv')
    
  })
  data1 <- reactive({
    data1 <- data() %>% slice(1) %>% mutate(frame = 1)
    for(i in seq(2,dim(data())[1],10)){
      print(i)
      data1 <- data1 %>% bind_rows(data() %>% slice(1:i) %>% mutate(frame = i)) 
    }
    
    data1
  })
  
  output$animation1 <- renderPlotly({
    p <- gapminder %>%
      plot_ly(
        x = ~gdpPercap,
        y = ~lifeExp,
        size = ~pop,
        color = ~continent,
        frame = ~year,
        text = ~country,
        hoverinfo = "text",
        type = 'scatter',
        mode = 'markers'
      ) %>%
      layout(
        xaxis = list(
          type = "log"
        )
      )
    
    p
    
  })
  
  output$animation2 <- renderPlotly({
    p <- plot_ly(data1(), x = ~x1, y = ~y1, z = ~z1, type = 'scatter3d', mode = 'lines',
                 line = list(color = 'red', width = 1),frame = ~frame)
    p
  })
  
  output$ThreeDplot1 <- renderPlotly({
    p <- plot_ly(data(), x = ~x1, y = ~y1, z = ~z1, type = 'scatter3d', mode = 'lines',
                 line = list(color = '#1f77b4', width = 1)) %>%
      add_trace(x = ~x2, y = ~y2, z = ~z2,
                line = list(color = 'rgb(44, 160, 44)', width = 1)) %>%
      add_trace(x = ~x3, y = ~y3, z = ~z3,
                line = list(color = 'bcbd22', width = 1))
    p
  })
  
  output$HeatMap1 <- renderPlotly({
    p <- plot_ly(z = volcano, type = "heatmap")
    p
  })
  
  output$RadarMap1 <- renderPlotly({
    p <- plot_ly(
      type = 'scatterpolar',
      fill = 'toself'
    ) %>%
      add_trace(
        r = c(39, 28, 8, 7, 28, 39),
        theta = c('A','B','C', 'D', 'E', 'A'),
        name = 'Group A'
      ) %>%
      add_trace(
        r = c(1.5, 10, 39, 31, 15, 1.5),
        theta = c('A','B','C', 'D', 'E', 'A'),
        name = 'Group B'
      )
    p
  })
  
  output$Distribution1 <- renderPlotly({
    p <- plot_ly(data = iris,x = ~Petal.Width,color = ~Species, type = "violin",box = list(
      visible = T
    ),meanline = list(
      visible = T
    ))
    p
  })
  
  output$Distribution2 <- renderPlotly({
    x <- rnorm(1000)
    y <- rnorm(1000)
    s <- subplot(
      plot_ly(x = x, color = I("black"), type = 'histogram'),
      plotly_empty(),
      plot_ly(x = x, y = y, type = 'histogram2dcontour', showscale = F),
      plot_ly(y = y, color = I("black"), type = 'histogram'),
      nrows = 2, heights = c(0.2, 0.8), widths = c(0.8, 0.2),
      shareX = TRUE, shareY = TRUE, titleX = FALSE, titleY = FALSE
    )
    s
  })
  
  output$Distribution3 <- renderPlotly({
    p <- plot_ly(alpha = 0.6) %>%
      add_histogram(x = ~rnorm(500)) %>%
      add_histogram(x = ~rnorm(500) + 1) %>%
      layout(barmode = "overlay")
    p
  })
  
  output$Distribution4 <- renderPlotly({
    p <- plot_ly(y = ~rnorm(50), type = "box", boxpoints = "all", jitter = 0.3,
                 pointpos = -1.8)
    p
  })
  
  output$Bar1 <- renderPlotly({
    data_mean <- ddply(ToothGrowth, c("supp", "dose"), summarise, length = mean(len))
    data_sd <- ddply(ToothGrowth, c("supp", "dose"), summarise, length = sd(len))
    data <- data.frame(data_mean, data_sd$length)
    data <- rename(data, c("data_sd.length" = "sd"))
    data$dose <- as.factor(data$dose)
    
    
    p <- plot_ly(data = data[which(data$supp == 'OJ'),], x = ~dose, y = ~length, type = 'bar',
                 error_y = ~list(array = sd,
                                 color = '#000000')) %>%
      add_trace(data = data[which(data$supp == 'VC'),], name = 'VC')
    
    p
  })
  
  output$sankey1 <- renderPlotly({
    p <- plot_ly(
      type = "sankey",
      
      orientation = "h",
      
      node = list(
        label = letters[1:5]
        
      ),
      
      link = list(
        source = c(0,1,2,3,0,0,0),
        target = c(1,2,3,4,2,3,4),
        value =  sample(c(1,2,3,4,5,6,7))
      )
    )
    p
  })

 
}

# Run the application 
shinyApp(ui = ui, server = server)
